import 'package:flutter/material.dart';
import 'package:flutter_uts_dandi/list.dart';

class Instax extends StatefulWidget {
  @override
  InstaxState createState() => InstaxState();
}

class InstaxState extends State<Instax> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 2,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            IconButton(
              icon: Image.asset("assets/back.png"),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            Container(
              width: 130,
              height: 130,
              child: IconButton(
                icon: Image.asset("assets/fujifilbanner.png"),
                onPressed: () {},
              ),
            ),
            IconButton(
              icon: Image.asset("assets/dotmenu.png"),
              onPressed: () {},
            ),
          ],
        ),
        automaticallyImplyLeading: false,
      ),
      body: getBody(),
    );
  }

  Widget getBody() {
    return ListView(
      children: <Widget>[
        Column(
          children: List.generate(datainstax.length, (index) {
            return Padding(
              padding:
                  EdgeInsets.only(right: 25, left: 25, bottom: 25, top: 25),
              child: Container(
                child: Column(children: <Widget>[
                  Container(
                    width: 380,
                    height: 170,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        alignment: Alignment.topCenter,
                        image: AssetImage("assets/" + datainstax[index]['img']),
                      ),
                    ),
                  )
                ]),
              ),
            );
          }),
        )
      ],
    );
  }
}
