import 'package:flutter/material.dart';
import 'package:flutter_uts_dandi/dashbord.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: DashBoard(),
  ));
}
