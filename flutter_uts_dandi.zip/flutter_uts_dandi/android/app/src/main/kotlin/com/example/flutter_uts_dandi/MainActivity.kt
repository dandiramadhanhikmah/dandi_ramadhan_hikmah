package com.example.flutter_uts_dandi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
